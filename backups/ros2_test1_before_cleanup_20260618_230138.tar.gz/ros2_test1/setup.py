from setuptools import setup
import os
from glob import glob

package_name = 'ros2_test1'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='cat',
    maintainer_email='cat@lubancat',
    description='Face detection with OpenCV',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            'face_detector = ros2_test1.face_detector:main',
        ],
    },
)
