#!/usr/bin/env python3
"""
多形状检测: 球体 + 方块 + 圆环 | 5色 | 网页推流 | 机械臂状态机
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import math, threading, time, copy
import cv2, numpy as np
import http.server, socketserver
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from shapes import detect_balls, detect_squares, detect_rings, COLORS

try: import serial
except: serial = None

# ============== 网页模板 ==============
PAGE = b"""<html><head><meta charset="utf-8"><title>Shape Detector</title></head>
<body style="margin:0;background:#000;text-align:center">
<img src="/video" style="max-width:100%">
<div style="color:#fff;font-size:16px;padding:8px;font-family:monospace" id="info">---</div>
<script>
var es=new EventSource("/stats");
es.onmessage=function(e){document.getElementById("info").innerHTML=e.data;}
</script>
</body></html>"""

# ============== 全局变量 ==============
frame, all_objects, info_text = None, [], "init"
lock = threading.Lock()
stream_running = True

class StreamHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200); self.send_header('Content-type','text/html;charset=utf-8'); self.end_headers()
            self.wfile.write(PAGE)
        elif self.path == '/video':
            self.send_response(200); self.send_header('Content-type','multipart/x-mixed-replace;boundary=frame'); self.end_headers()
            while stream_running:
                with lock: img = frame.copy() if frame is not None else None
                if img is not None:
                    _,jpg=cv2.imencode('.jpg',img,[cv2.IMWRITE_JPEG_QUALITY,90])
                    self.wfile.write(b'--frame\r\nContent-Type:image/jpeg\r\n\r\n')
                    self.wfile.write(jpg.tobytes()); self.wfile.write(b'\r\n')
                time.sleep(0.04)
        elif self.path == '/stats':
            self.send_response(200); self.send_header('Content-type','text/event-stream'); self.end_headers()
            while stream_running:
                self.wfile.write('data: {}\n\n'.format(info_text).encode()); self.wfile.flush(); time.sleep(0.3)
    def log_message(self,*a): pass

class ThreadedServer(http.server.HTTPServer):
    allow_reuse_address=True

DRAW_COLORS = {
    'yellow': (0,255,255), 'blue':(255,0,0), 'green':(0,255,0),
    'red':(0,0,255), 'white':(255,255,255)
}

class ShapeArmNode(Node):
    def __init__(self):
        super().__init__('shape_arm')

        self.declare_parameter('publish_rate', 30.0)
        self.declare_parameter('joint_step', 0.03)
        self.declare_parameter('initial_hold_seconds', 5.0)
        self.declare_parameter('gripper_open_seconds', 0.8)
        self.declare_parameter('enable_serial', False)
        self.declare_parameter('serial_port', '/dev/ttyS0')
        self.declare_parameter('baud_rate', 115200)
        self.declare_parameter('target_shape', 'ball')
        self.declare_parameter('target_color', 'yellow')

        self.publish_rate = self.get_parameter('publish_rate').value
        self.joint_step   = self.get_parameter('joint_step').value
        self.initial_hold = self.get_parameter('initial_hold_seconds').value
        self.grip_open_s  = self.get_parameter('gripper_open_seconds').value
        self.enable_serial = self.get_parameter('enable_serial').value
        self.serial_port  = self.get_parameter('serial_port').value
        self.baud_rate    = self.get_parameter('baud_rate').value
        self.target_shape = self.get_parameter('target_shape').value
        self.target_color = self.get_parameter('target_color').value

        # 关节
        self.pan=0.0; self.p1=1.0; self.p2=-2.6; self.p3=-1.35; self.gs=0.0; self.gl=0.0

        # 状态机
        self.state='init_folded'; self.st=None
        self.grip_state='idle'; self.grip_st=None; self.was_seen=False
        self.swing_state=0 # 0=idle, 1=forward, 2=back
        self.swing_timer=0

        # 摄像头
        self.cap = cv2.VideoCapture(20, cv2.CAP_V4L2)
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.w = 640; self.h = 480
        if not self.cap.isOpened():
            self.get_logger().error('Camera fail'); raise RuntimeError

        # 串口
        self.ser=None; self.ser_ok=False
        if self.enable_serial and serial:
            try:
                self.ser=serial.Serial(self.serial_port, self.baud_rate, timeout=0.05)
                self.ser_ok=True
                self.get_logger().info('Serial OK')
            except: pass

        self.joint_pub = self.create_publisher(JointState, 'joint_states', 10)
        self.servo_pub = self.create_publisher(String, '/servo_cmd', 10)
        self.timer = self.create_timer(1.0/self.publish_rate, self.tick)
        self.fc, self.t0 = 0, time.time()
        self.get_logger().info('ShapeArm ready. Target: {} {}'.format(self.target_color, self.target_shape))

    folded  = {'pan':0.0,'p1':1.0,'p2':-2.6,'p3':-1.35,'gs':0.0}
    search  = {'pan':0.0,'p1':-0.22,'p2':-0.765,'p3':-0.8,'gs':-1.0}

    def _step(self, cur, tgt):
        d=tgt-cur
        if abs(d)<=self.joint_step: return tgt
        return cur+math.copysign(self.joint_step,d)

    def _move(self, pose):
        self.pan=self._step(self.pan,pose['pan']); self.p1=self._step(self.p1,pose['p1'])
        self.p2=self._step(self.p2,pose['p2']); self.p3=self._step(self.p3,pose['p3'])
        self.gs=self._step(self.gs,pose['gs'])

    def tick(self):
        global frame, all_objects, info_text
        ret, img = self.cap.read()
        if not ret: return

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # --- 多形状检测 ---
        balls   = detect_balls(hsv)
        squares = detect_squares(hsv)
        rings   = detect_rings(hsv)
        all_objects = balls + squares + rings

        # --- 匹配目标 ---
        target = None
        for obj in all_objects:
            if obj['type'] == self.target_shape and obj['color'] == self.target_color:
                target = obj; break

        # --- 绘制 ---
        for obj in balls:
            x,y=obj['center']; r=obj['radius']; c=DRAW_COLORS.get(obj['color'],(0,255,0))
            cv2.circle(img,(x,y),r,c,2); cv2.putText(img,obj['color'][:1].upper(),(x+5,y-5),cv2.FONT_HERSHEY_SIMPLEX,0.5,c,2)
        for obj in squares:
            rect=cv2.minAreaRect(np.array([[obj['center'][0]-obj['width']//2,obj['center'][1]-obj['height']//2],
                  [obj['center'][0]+obj['width']//2,obj['center'][1]-obj['height']//2],
                  [obj['center'][0]+obj['width']//2,obj['center'][1]+obj['height']//2],
                  [obj['center'][0]-obj['width']//2,obj['center'][1]+obj['height']//2]]))
            box=cv2.boxPoints(rect); box=np.int32(box)
            c=DRAW_COLORS.get(obj['color'],(0,255,0))
            cv2.drawContours(img,[box],0,c,2); cv2.putText(img,obj['color'][:1].upper(),
                (obj['center'][0]+5,obj['center'][1]-5),cv2.FONT_HERSHEY_SIMPLEX,0.5,c,2)
        for obj in rings:
            x,y=obj['center']; c=DRAW_COLORS.get(obj['color'],(0,255,0))
            cv2.circle(img,(x,y),obj['outer_r'],c,2)
            if obj['inner_r']>0: cv2.circle(img,(x,y),obj['inner_r'],c,1)
            cv2.putText(img,obj['color'][:1].upper(),(x+5,y-5),cv2.FONT_HERSHEY_SIMPLEX,0.5,c,2)

        # --- 状态机 ---
        now=time.time()
        if self.st is None: self.st=now
        if self.state=='init_folded':
            self._move(self.folded)
            if now-self.st>self.initial_hold: self.state='search'; self.get_logger().info('-> search')
        elif self.state in ('search','target_seen'):
            self._move(self.search)
            self.state='target_seen' if target else 'search'

        # --- 夹爪 ---
        tjust = target and not self.was_seen
        if self.grip_state=='idle':
            self.gl=self._step(self.gl,0.0)
            if tjust: self.grip_state='open'; self.grip_st=now
        elif self.grip_state=='open':
            self.gl=self._step(self.gl,1.0)
            if self.gl==1.0: self.grip_state='hold'; self.grip_st=now
        elif self.grip_state=='hold':
            self.gl=1.0
            if now-self.grip_st>=self.grip_open_s: self.grip_state='close'
        elif self.grip_state=='close':
            self.gl=self._step(self.gl,0.0)
            if self.gl==0.0: self.grip_state='idle'; self.grip_st=None
        self.was_seen = target is not None

        # --- 标注目标 ---
        if target:
            tx,ty=target['center']
            cv2.circle(img,(tx,ty),30,(0,0,255),3); cv2.line(img,(tx-20,ty),(tx+20,ty),(0,0,255),2); cv2.line(img,(tx,ty-20),(tx,ty+20),(0,0,255),2)

        counts = ' | '.join([f'{t}:{sum(1 for o in all_objects if o["type"]==t)}' for t in ['ball','square','ring']])
        info_text = '{} | Grip:{} | {} | Target:{}-{}<br>{}'.format(self.state,self.grip_state,counts,self.target_color,self.target_shape,'FOUND' if target else '')

        cv2.putText(img, f'{self.state} {self.target_color}-{self.target_shape}', (10,30), cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,255,0),2)
        cv2.putText(img, counts, (10,55), cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,255,255),1)

        with lock: frame=img.copy()

        # --- 发布关节 ---
        jm=JointState(); jm.header.stamp=self.get_clock().now().to_msg()
        jm.name=['joint_pan','joint_pitch_1','joint_pitch_2','joint_pitch_3','joint_gripper_servo','joint_gripper_left']
        jm.position=[self.pan,self.p1,self.p2,self.p3,self.gs,self.gl]
        self.joint_pub.publish(jm)

        yb = [o for o in all_objects if o['type']=='ball' and o['color']=='yellow']
        # --- 黄球触发往复摆动 ---
        if yb and self.swing_state == 0:
            self.swing_state = 1
            self.swing_timer = 0
        if self.swing_state == 1:
            self.servo_pub.publish(String(data='1:2500'))
            self.servo_pub.publish(String(data='2:2500'))
            self.swing_state = 2
            self.swing_timer = 0
        elif self.swing_state == 2:
            self.swing_timer += 1
            if self.swing_timer > 30:  # ~1 second at 30fps
                self.servo_pub.publish(String(data='1:500'))
                self.servo_pub.publish(String(data='2:500'))
                self.swing_state = 0

        if self.ser_ok:
            try:
                degs=','.join([f'{90+28.65*a:.1f}' for a in jm.position])
                self.ser.write(f'SYNC,{degs}\n'.encode()); self.ser.flush()
            except: self.ser_ok=False

        self.fc+=1
        if self.fc%30==0:
            e=time.time()-self.t0
            self.get_logger().info(f'FPS:{self.fc/e:.1f} {self.state} {counts}')

    def destroy_node(self):
        global stream_running
        stream_running=False; self.cap.release()
        if self.ser: self.ser.close()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    s=ThreadedServer(('0.0.0.0',8080),StreamHandler)
    threading.Thread(target=s.serve_forever,daemon=True).start()
    print('\n  http://192.168.137.207:8080\n')
    try:
        node=ShapeArmNode(); rclpy.spin(node)
    except Exception as e: print('Error:',e)
    finally:
        stream_running=False; s.shutdown(); rclpy.shutdown()

if __name__=='__main__': main()
